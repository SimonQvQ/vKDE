// SPDX-License-Identifier: GPL-3.0-only
#include <QApplication>
#include <QQmlComponent>
#include <QQmlEngine>
#include <QQmlContext>
#include <QQuickItem>
#include <QPainter>
#include <QTemporaryDir>
#include <QFile>
#include <QTest>
#include <KDecoration3/Decoration>
#include <KDecoration3/DecoratedWindow>

class PreviewTest : public QObject {
    Q_OBJECT
private Q_SLOTS:
    void renderAndLifecycle()
    {
        QTemporaryDir config;
        QVERIFY(config.isValid());
        qputenv("XDG_CONFIG_HOME", config.path().toUtf8());
        QQmlEngine engine;
        engine.rootContext()->setContextProperty(QStringLiteral("testPlugin"), qEnvironmentVariable("BREEZE_BLURRED_TEST_PLUGIN", QStringLiteral("org.kde.breezeblurred6")));
        QQmlComponent component(&engine);
        component.setData(R"(
import QtQuick
import org.kde.kwin.private.kdecoration as Deco
Item {
    width: 700; height: 450
    Deco.Bridge { id: bridgeItem; objectName: "bridge"; plugin: testPlugin }
    Deco.Settings { id: settingsItem; bridge: bridgeItem.bridge }
    Deco.Decoration {
        objectName: "preview"; width: 700; height: 450
        bridge: bridgeItem.bridge; settings: settingsItem; drawBackground: false
    }
}
)", QUrl(QStringLiteral("file:///preview-test.qml")));
        QVERIFY2(component.isReady(), qPrintable(component.errorString()));
        std::unique_ptr<QObject> root(component.create());
        QVERIFY2(root != nullptr, qPrintable(component.errorString()));
        auto bridge = root->findChild<QObject *>(QStringLiteral("bridge"));
        QVERIFY(bridge);
        QVERIFY(bridge->property("valid").toBool());
        auto preview = root->findChild<QObject *>(QStringLiteral("preview"));
        QVERIFY(preview);
        QTest::qWait(50);
        auto deco = preview->property("decoration").value<KDecoration3::Decoration *>();
        QVERIFY(deco);
        QVERIFY(!deco->isOpaque());
        QVERIFY(!deco->blurRegion().isEmpty());
        auto titlePoint = [&] { return QPoint(deco->size().width() / 2, deco->borderTop() / 2); };
        QVERIFY(deco->blurRegion().contains(titlePoint()));
        QVERIFY(!deco->blurRegion().contains(QPoint(deco->size().width() / 2, deco->size().height() / 2)));
        QImage image(deco->size().toSize(), QImage::Format_ARGB32_Premultiplied);
        image.fill(Qt::transparent);
        {
            QPainter painter(&image);
            deco->paint(&painter, deco->rect());
            deco->paint(&painter, deco->rect());
        }
        // Repainting and the two background layers must not accumulate alpha.
        const int alpha = image.pixelColor(image.width() / 3, 2).alpha();
        QVERIFY2(qAbs(alpha - 204) <= 1, qPrintable(QStringLiteral("Expected 80% alpha, got %1").arg(alpha)));
        auto client = preview->property("client").value<QObject *>();
        QVERIFY(client);
        QVERIFY(client->setProperty("active", false));
        QVERIFY(client->setProperty("width", 900.0));
        QTest::qWait(20);
        QVERIFY(deco->blurRegion().contains(titlePoint()));
        QVERIFY(client->setProperty("maximizedHorizontally", true));
        QVERIFY(client->setProperty("maximizedVertically", true));
        QTest::qWait(20);
        QVERIFY(!deco->isOpaque());
        QVERIFY(deco->blurRegion().contains(titlePoint()));
        QVERIFY(client->setProperty("shaded", true));
        QTest::qWait(20);
        QVERIFY(!deco->blurRegion().isEmpty());
        QVERIFY(client->setProperty("shaded", false));
        QVERIFY(client->setProperty("maximizedHorizontally", false));
        QVERIFY(client->setProperty("maximizedVertically", false));
        QTest::qWait(20);
        QVERIFY(!deco->blurRegion().contains(QPoint(deco->size().width() / 2, deco->size().height() / 2)));
        auto configure = [&](const QByteArray &contents) {
            QFile file(config.filePath(QStringLiteral("breezeblurred6rc")));
            if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) return false;
            if (file.write(contents) != contents.size()) return false;
            file.close();
            return QMetaObject::invokeMethod(deco, "reconfigure");
        };
        QVERIFY(configure("[Glass]\nOpacity=1.0\nBlur=true\n"));
        QVERIFY(deco->isOpaque());
        QVERIFY(deco->blurRegion().isEmpty());
        QVERIFY(configure("[Glass]\nOpacity=0.8\nBlur=false\n"));
        QVERIFY(!deco->isOpaque());
        QVERIFY(deco->blurRegion().isEmpty());
        QVERIFY(configure("[Glass]\nOpacity=0.8\nBlur=true\n"));
        QVERIFY(!deco->blurRegion().isEmpty());
    }
};
QTEST_MAIN(PreviewTest)
#include "preview-test.moc"
