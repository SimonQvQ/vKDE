// SPDX-License-Identifier: GPL-3.0-only
#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QTimer>
#include <QDebug>
#include <cstdio>
int main(int argc,char **argv) {
    QApplication app(argc,argv);
    app.setApplicationName(QStringLiteral("Breeze Blurred 6 Live Check"));
    app.setDesktopFileName(QStringLiteral("org.kde.breezeblurred6.livecheck"));
    QMainWindow window;
    window.setWindowTitle(QStringLiteral("Breeze Blurred 6 — 80% Glass"));
    window.resize(820,460);
    auto central=new QWidget(&window);
    auto layout=new QVBoxLayout(central);
    auto label=new QLabel(QStringLiteral("<h1>Breeze Blurred 6</h1><p>Plasma 6 · Qt 6 · KDecoration3</p><p>80% opaque glass, sharp text and buttons.</p>"),central);
    label->setAlignment(Qt::AlignCenter);layout->addWidget(label,1);
    auto button=new QPushButton(QStringLiteral("Rounded panels · Larger Arch launcher"),central);layout->addWidget(button);window.setCentralWidget(central);
    window.show();
    std::fprintf(stderr,"LIVE_CHECK_READY\n");std::fflush(stderr);
    QTimer::singleShot(12000,&window,[&window](){window.resize(900,474);});
    QTimer::singleShot(60000,&app,&QApplication::quit);
    return app.exec();
}
