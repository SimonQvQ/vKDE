# Breeze Blurred 6

A Plasma 6.7 / Qt 6 / KDecoration3 adaptation built on KDE's Breeze decoration.
Upstream: https://github.com/KDE/breeze, Plasma/6.7 commit ca217f12ce16a28e601c78b7f2fdceca586725b2.
Original KDE copyrights and SPDX licenses are preserved. This is a modified Breeze implementation, not a from-scratch rewrite.

## Changes

- Separate plugin `org.kde.breezeblurred6`; system Breeze is untouched.
- Separate `breezeblurred6rc` settings; standard Breeze buttons, layout and shadows retained.
- Adjustable background opacity and optional tint; caption and button foregrounds remain opaque.
- KDecoration3 blur region covers only the decoration, subtracting the application region and excluding shadow padding.
- Updates blur on resize, maximize, shade, border and configuration changes.
- Source-composition painting keeps effective opacity at 80% instead of accumulating opacity through double background painting or repaints.
- No custom KCM yet; settings are stored under `[Glass]` in `~/.config/breezeblurred6rc`:

```
[Glass]
Opacity=0.8
Blur=true
TintColor=#333333
```

## Build and verify

```
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build -j4
ctest --test-dir build --output-on-failure
```

The preview test uses KWin's actual decoration preview bridge in an isolated offscreen process. It checks factory loading, blur bounds, 80% alpha after repeated rendering, activity changes, resize, maximize and shade lifecycle.

## Install

```
sudo install -Dm755 build/stage/org.kde.kdecoration3/org.kde.breezeblurred6.so /usr/lib/qt6/plugins/org.kde.kdecoration3/org.kde.breezeblurred6.so
kwriteconfig6 --file kwinrc --group org.kde.kdecoration2 --key library org.kde.breezeblurred6
qdbus6 org.kde.KWin /KWin org.kde.KWin.reconfigure
```

## Roll back

```
kwriteconfig6 --file kwinrc --group org.kde.kdecoration2 --key library org.kde.breeze
qdbus6 org.kde.KWin /KWin org.kde.KWin.reconfigure
```

Uninstall only after switching to another decoration. Rebuild against the installed KDecoration3 API after incompatible KDE updates. No session restart is required to switch decorations.
